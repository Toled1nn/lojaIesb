package br.com.api.loja.endpoints;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.api.loja.classes_avulsas.CadastroGeral;
import br.com.api.loja.classes_avulsas.ControladorSessao;
import br.com.api.loja.entidades.CarrinhoCliente;
import br.com.api.loja.entidades.Cliente;
import br.com.api.loja.entidades.EnderecoCliente;
import br.com.api.loja.entidades.Produto;
import br.com.api.loja.entidades.Venda;
import br.com.api.loja.jpa.CarrinhoClienteJPA;
import br.com.api.loja.jpa.ClienteJPA;
import br.com.api.loja.jpa.EnderecoClienteJPA;
import br.com.api.loja.jpa.ProdutoJPA;
import br.com.api.loja.jpa.VendaJPA;


@RestController
public class EndPointsCarrinho {
	
	@Autowired
	private CarrinhoClienteJPA carrinhoJPA;
	
	@Autowired
	private ProdutoJPA produtoJPA;
	
	@Autowired
	private EnderecoClienteJPA enderecoClienteJPA;
	
	@Autowired
	private VendaJPA vendaJPA;
	
	@Autowired
	private ClienteJPA clienteJPA;
	
	@PostMapping(value = "cadastraCarrinho")
    @ResponseBody
    public ResponseEntity<?> cadastrarCarrinho(@RequestBody CarrinhoCliente carrinho, Long idCliente, Long idVenda,Long idEnderecoCobranca, Long idEnderecoEntrega){
		Cliente cli = clienteJPA.findById(idCliente).get();
		if(cli == null) {
			return new ResponseEntity<String>("Cliente não cadastrado", HttpStatus.OK);
		}
		
		List<String> validacoes = CadastroGeral.getInstance().cadastraCarrinho(carrinho);
		if(validacoes.size() > 0) {
			if(carrinhoJPA.findById(carrinho.getIdCarrinho()).get() != null)
				return new ResponseEntity<String>("Carrinho já cadastrado", HttpStatus.OK);
			EnderecoCliente enderecoEntrega = enderecoClienteJPA.findById(idEnderecoEntrega).get();
			EnderecoCliente enderecoCobranca = enderecoClienteJPA.findById(idEnderecoCobranca).get();
			Venda venda = vendaJPA.findById(idVenda).get();
			CarrinhoCliente carrinhoCadastrar = new CarrinhoCliente.CarrinhoClienteBuilder()
			.idCarrinho(carrinho.getIdCarrinho())
			.cupomDesconto(carrinho.getCupomDesconto())
			.precoTotal(0)
			.enderecoEntrega(enderecoEntrega)
			.enderecoCobranca(enderecoCobranca)
			.venda(venda)
			.processoCarrinho(0)
			.cliente(cli)
			.qtdTotalProdCarrinho(0)
			.build();
			
			carrinhoCadastrar = carrinhoJPA.save(carrinhoCadastrar);
			return new ResponseEntity<CarrinhoCliente>(carrinhoCadastrar, HttpStatus.CREATED);
		}else {
			return new ResponseEntity<List<String>>(validacoes, HttpStatus.OK);
			
		}
    }
	
	@PutMapping(value = "finalizaCarrinho")
    @ResponseBody
    public ResponseEntity<?> finalizarCompra(@RequestBody Long id){
		CarrinhoCliente carrinhoCadastrar = carrinhoJPA.findById(id).get();
		if(carrinhoCadastrar == null)
			return new ResponseEntity<String>("Carrinho não cadastrado", HttpStatus.OK);
		if(!(ControladorSessao.getInstance().verificaAutenticacao(carrinhoCadastrar.getCliente().getNome())))
			return new ResponseEntity<String>("Usuario não está autenticado", HttpStatus.OK);
		carrinhoCadastrar.setProcessoCarrinho(2);
		carrinhoCadastrar = carrinhoJPA.saveAndFlush(carrinhoCadastrar);
		
		return new ResponseEntity<CarrinhoCliente>(carrinhoCadastrar, HttpStatus.OK);
		
    }
	
	@PutMapping(value = "adicionarProdutoCarrinho")
    @ResponseBody
    public ResponseEntity<?> adicionarProdutoCarrinho(@RequestBody Long idCarrinho,Long codProduto,int qtd){
		Produto prod = produtoJPA.findById(codProduto).get();
		if(prod == null)
			return new ResponseEntity<String>("Produto não cadastrado", HttpStatus.OK);
		CarrinhoCliente car = carrinhoJPA.findById(idCarrinho).get();
		if(car == null)
			return new ResponseEntity<String>("Carrinho não cadastrado", HttpStatus.OK);
		if(car.getProcessoCarrinho() != 2) {
			if(car.verificaProdutoAdicionadoCarrinho(car.getProdutos(), prod.getNome())) {
				car.setProdutos(car.removeProdLista(car.getProdutos(), prod.getNome()));
				car.setProdutos(car.adicionaProdutos(car.getProdutos(), prod.getNome(), qtd));
				car.setQtdTotalProdCarrinho(car.calculaQtdProdutoCarrinho(car.getProdutos())); 
				
			}else {
				car.setProdutos(car.adicionaProdutos(car.getProdutos(), prod.getNome(), qtd));
				car.setQtdTotalProdCarrinho(car.calculaQtdProdutoCarrinho(car.getProdutos())); 
				car.setProcessoCarrinho(1);
			}
			car = carrinhoJPA.saveAndFlush(car);
			
			return new ResponseEntity<CarrinhoCliente>(car, HttpStatus.OK);
		}else {
			return new ResponseEntity<String>("Carrinho Já foi finalizada a Compra", HttpStatus.OK);
		}

		
    }
	
	@PostMapping(value = "imprimeCarrinhoFinalizado")
    @ResponseBody
    public ResponseEntity<?> mostraDadosCompra(@RequestBody Long idCarrinho){
		List<String> dadosCompra = new ArrayList<String>();
		CarrinhoCliente car = carrinhoJPA.findById(idCarrinho).get();
		if(car == null)
			return new ResponseEntity<String>("Carrinho não cadastrado", HttpStatus.OK);
		if(!(ControladorSessao.getInstance().verificaAutenticacao(car.getCliente().getNome())))
			return new ResponseEntity<String>("Usuario não está autenticado", HttpStatus.OK);
		Cliente cliente = clienteJPA.findById(car.getCliente().getId()).get();
		//EnderecoCliente end = enderecoClienteJPA.buscaEnderecoPorCliente(cliente.getId());
		//Venda venda = vendaJPA.buscaEnderecoPorCliente(cliente.getId());
		
		dadosCompra.add(car.toString());
		dadosCompra.add(cliente.toString());
		dadosCompra.add(car.getVenda().toString());
		dadosCompra.add(car.getEnderecoCobranca().toString());
		dadosCompra.add(car.getEnderecoEntrega().toString());
		//dadosCompra.add(end.toString());
		//dadosCompra.add(venda.toString());
		
		return new ResponseEntity<List<String>>(dadosCompra,HttpStatus.OK);
	}
		
}
