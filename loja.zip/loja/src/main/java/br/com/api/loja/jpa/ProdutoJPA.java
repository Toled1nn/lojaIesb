package br.com.api.loja.jpa;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import br.com.api.loja.entidades.Produto;

@Repository
public interface ProdutoJPA extends JpaRepository<Produto, Long>{
	
	@Query(value = "select car from CarrinhoCliente car where car.produtos like :nomeProduto ")
	Produto verificaProdutoCarrinho(@Param("nomeProduto") String nomeProduto);

}
