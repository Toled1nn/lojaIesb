package br.com.api.loja.endpoints;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.api.loja.classes_avulsas.CadastroGeral;
import br.com.api.loja.entidades.Produto;
import br.com.api.loja.jpa.ProdutoJPA;




@RestController
public class EndPointsProduto {
	
	@Autowired
	private static ProdutoJPA produtoJPA;
	
	@PostMapping(value = "cadastrarProduto")
    @ResponseBody
    public ResponseEntity<?> cadastrarProduto(@RequestBody Produto prod){
		
		List<String> validacoes = CadastroGeral.getInstance().cadastroProduto(prod);
		if(validacoes.size() > 0) {
			if(produtoJPA.findById(prod.getCodigoProduto()).get() != null)
				return new ResponseEntity<String>("ESTE PRODUTO JA FOI CADASTRADO", HttpStatus.OK);
			Produto pro = new Produto.ProdutoBuilder()
			 .codigoProduto(prod.getCodigoProduto())
			 .nome(prod.getNome())
			 .precoProduto(prod.getPrecoProduto())
			 .quantidadeEstoque(prod.getQuantidadeEstoque())
			 .build();
			pro = produtoJPA.save(pro);
			return new ResponseEntity<Produto>(pro, HttpStatus.CREATED);
		}
		else {
			return new ResponseEntity<List<String>>(validacoes, HttpStatus.OK);
		}
			
    }
	
	@GetMapping(value = "listarProduto")
    @ResponseBody 
    public ResponseEntity<List<Produto>> listaProduto(){
    	List<Produto> produtos = produtoJPA.findAll();
    	return new ResponseEntity<List<Produto>>(produtos, HttpStatus.OK);
    }
	
	@DeleteMapping(value = "deletarProduto")
    @ResponseBody
	public ResponseEntity<String> delete(@RequestParam String nomeProduto){
    	Produto prodDel = produtoJPA.verificaProdutoCarrinho(nomeProduto);
	 	if(prodDel != null) {
	 		produtoJPA.deleteById(prodDel.getCodigoProduto());
	 		return new ResponseEntity<String>("Produto Deletado", HttpStatus.OK);
	 	}else {
	 		return new ResponseEntity<String>("Produto Não pode ser excluido", HttpStatus.OK);
	 	}
    	
    }
	
	@PutMapping(value = "atualizarProduto")
    @ResponseBody /*  Retorna os dados paara o corpo da resposta   */
    public ResponseEntity<?> atualizar(@RequestBody Produto prod){
		List<String> validacoes = CadastroGeral.getInstance().cadastroProduto(prod);
		if(validacoes.size() > 0) {
			Produto pro = new Produto.ProdutoBuilder()
					 .codigoProduto(prod.getCodigoProduto())
					 .nome(prod.getNome())
					 .precoProduto(prod.getPrecoProduto())
					 .quantidadeEstoque(prod.getQuantidadeEstoque())
					 .build();
			pro = produtoJPA.saveAndFlush(pro);
			return new ResponseEntity<Produto>(pro, HttpStatus.OK);
		}
		else {
			return new ResponseEntity<List<String>>(validacoes, HttpStatus.OK);
		}
    }

}
